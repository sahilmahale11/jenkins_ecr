#!/bin/bash
#remove all files
rm -rf /etc/apache2/apache2.conf
rm -rf /etc/apache2/sites-available/*.conf
