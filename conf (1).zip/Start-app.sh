#!/bin/bash
apachectl configtest
systemctl restart apache2
