#!/bin/bash
cd /home/tibcowww/temp/apache2/
mv apache2.conf /etc/apache2/
for i in *.conf; do
  cp $i /etc/apache2/sites-available/
  a2ensite $i
done
