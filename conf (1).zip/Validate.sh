!/bin/bash
netstat -lntp | grep 80
